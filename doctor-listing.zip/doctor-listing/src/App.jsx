import React from "react";
import { Routes, Route } from "react-router-dom";
import DoctorListingPage from "./DoctorListingPage";

const App = () => {
  return (
    <Routes>
      <Route path="/" element={<DoctorListingPage />} />
    </Routes>
  );
};

export default App;
